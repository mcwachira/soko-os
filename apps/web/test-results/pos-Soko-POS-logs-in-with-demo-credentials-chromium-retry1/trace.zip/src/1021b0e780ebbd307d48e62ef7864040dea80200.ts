import { test, expect } from '@playwright/test';

test.describe('Soko POS', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('shows login form when not authenticated', async ({ page }) => {
    await expect(page.getByText('SOKO POS Login')).toBeVisible();
    await expect(page.getByPlaceholder('test@example.com')).toBeVisible();
    await expect(page.getByPlaceholder('password')).toBeVisible();
  });

  test('logs in with demo credentials', async ({ page }) => {
    await page.getByPlaceholder('test@example.com').fill('test@example.com');
    await page.getByPlaceholder('password').fill('password');
    await page.getByRole('button', { name: 'Sign In' }).click();

    await expect(page.getByText('SOKO POS')).toBeVisible();
    await expect(page.getByText(/ONLINE|OFFLINE MODE/)).toBeVisible();
  });

  test('login shows error on invalid credentials', async ({ page }) => {
    await page.getByPlaceholder('test@example.com').fill('bad@example.com');
    await page.getByPlaceholder('password').fill('wrong');
    await page.getByRole('button', { name: 'Sign In' }).click();

    await expect(page.getByText(/Login failed|Invalid credentials/)).toBeVisible();
  });
});
